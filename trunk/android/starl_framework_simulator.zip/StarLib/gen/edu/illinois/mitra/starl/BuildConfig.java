/** Automatically generated file. DO NOT MODIFY */
package edu.illinois.mitra.starl;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}