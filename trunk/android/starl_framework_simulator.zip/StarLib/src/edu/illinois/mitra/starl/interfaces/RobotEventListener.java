package edu.illinois.mitra.starl.interfaces;

public interface RobotEventListener {
	public void robotEvent(int type, int event);
}
