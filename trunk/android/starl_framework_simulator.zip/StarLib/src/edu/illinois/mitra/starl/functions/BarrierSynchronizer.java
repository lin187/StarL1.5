package edu.illinois.mitra.starl.functions;

import java.util.HashMap;
import java.util.HashSet;

import edu.illinois.mitra.starl.comms.MessageContents;
import edu.illinois.mitra.starl.comms.RobotMessage;
import edu.illinois.mitra.starl.gvh.GlobalVarHolder;
import edu.illinois.mitra.starl.interfaces.MessageListener;
import edu.illinois.mitra.starl.interfaces.Synchronizer;
import edu.illinois.mitra.starl.objects.Common;

public class BarrierSynchronizer implements Synchronizer, MessageListener {
	private static final String TAG = "BarrierSynchronizer";
	private static final String ERR = "Critical Error";
	
	private GlobalVarHolder gvh;
	// Barriers tracks which barriers are active and how many robots have reported ready to proceed for each
	// Keys are barrier IDs, values are number of robots ready to proceed
	private HashMap<String,HashSet<String>> barriersNames;
	private int n_participants;
	private String name;
	
	public BarrierSynchronizer(GlobalVarHolder gvh) {
		this.gvh = gvh;
		n_participants = gvh.id.getParticipants().size();
		barriersNames = new HashMap<String,HashSet<String>>();
		name = gvh.id.getName();
		gvh.comms.addMsgListener(Common.MSG_BARRIERSYNC, this);
		gvh.trace.traceEvent(TAG, "Created");
		gvh.log.i(TAG, "Created BarrierSynchronizer, registered message listener with GVH");
	}
	
	public void barrier_sync(String barrierID) {	 
		HashSet<String> names;
		if(barriersNames.containsKey(barrierID)) {
			if(barriersNames.get(barrierID).contains(name)) {
				// Already requested entry!
				gvh.log.e(TAG, "TRIED TO SYNC MULTIPLE TIMES FOR BID " + barrierID);
				return;
			} else {
				names = barriersNames.get(barrierID);
			}
		} else {
			names = new HashSet<String>();
		}
		names.add(name);
		barriersNames.put(barrierID, names);
		
		gvh.log.e(TAG, "SENDING SYNC FOR ID " + barrierID);
		RobotMessage notify_sync = new RobotMessage("ALL", name, Common.MSG_BARRIERSYNC, new MessageContents(barrierID));
		gvh.comms.addOutgoingMessage(notify_sync);
	}
	
	public boolean barrier_proceed(String barrierID) {
		try {
			if(barriersNames.get(barrierID).size() == n_participants) {
				gvh.trace.traceEvent(TAG, "Barrier ready to proceed", barrierID);
				gvh.log.i(TAG, "Barrier " + barrierID + " has all robots ready to proceed!");
				barriersNames.remove(barrierID);
				return true;
			}
		} catch(NullPointerException e) {}
		return false;
	}

	@Override
	public void messageReceied(RobotMessage m) {
		// Update the barriers when a barrier sync message is received
		String bID = m.getContents(0);
		
		gvh.trace.traceEvent(TAG, "Received barrier sync message", bID);

		HashSet<String> names;
		if(barriersNames.containsKey(bID)) {
			names = barriersNames.get(bID);
			if(names.contains(m.getFrom())) {
				gvh.log.e(TAG, "Received duplicate sync message from " + m.getFrom() + "!");
				return;
			} else {
				names.add(m.getFrom());
			}
		} else {
			names = new HashSet<String>();
			names.add(m.getFrom());
		}
		barriersNames.put(bID, names);
		gvh.log.d(TAG, "Received barrier notice for bID " + bID + " from " + m.getFrom() + ". Current count: " + barriersNames.get(bID).size());
	}
	
	@Override
	public void cancel() {
		gvh.comms.removeMsgListener(Common.MSG_BARRIERSYNC);
		gvh.trace.traceEvent(TAG, "Cancelled");
	}
}
