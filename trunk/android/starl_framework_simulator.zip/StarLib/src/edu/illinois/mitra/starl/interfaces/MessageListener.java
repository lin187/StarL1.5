package edu.illinois.mitra.starl.interfaces;

import edu.illinois.mitra.starl.comms.RobotMessage;

public interface MessageListener {
	public void messageReceied(RobotMessage m);	
}
