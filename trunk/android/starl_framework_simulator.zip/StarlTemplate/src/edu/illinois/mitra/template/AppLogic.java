package edu.illinois.mitra.template;

import java.util.LinkedList;

import edu.illinois.mitra.starl.gvh.GlobalVarHolder;
import edu.illinois.mitra.starl.interfaces.LogicThread;

public class AppLogic extends LogicThread {

	public AppLogic(GlobalVarHolder gvh) {
		super(gvh);
	}
	
	@Override
	public LinkedList<Object> call() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
